﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;

namespace SettingsManager {
  /// <summary>
  /// Reads settings from a SettingsBase object, and orders them into categories and groups.
  /// </summary>
  internal static class CategoryFactory {
    public static ReadOnlyCollection<SettingCategory> GetCategories(SettingsBase settings) {
      List<SettingCategory> categories = new List<SettingCategory>();

      foreach (PropertyInfo propertyInfo in settings.GetType().GetProperties()) {
        object[] customAttributes = propertyInfo.GetCustomAttributes(typeof(SettingAttribute), true);
        foreach (object customAttribute in customAttributes) {
          if (customAttribute.GetType() == typeof(SettingAttribute)) {
            SettingAttribute settingAttribute = (SettingAttribute)customAttribute;
            SettingCategory category = CategoryFactory.getCategory(categories, settingAttribute.Category);
            SettingGroup group = CategoryFactory.getGroup(category, settingAttribute.Group);
            object propertyValue = propertyInfo.GetValue(settings, null);

            SettingEditorBase editor = (SettingEditorBase)Activator.CreateInstance(settingAttribute.EditorType, new object[] { settingAttribute.Description, propertyValue });
            editor.settings = settings;
            editor.propertyInfo = propertyInfo;

            group.Editors.Add(editor);
          }
        }
      }

      return new ReadOnlyCollection<SettingCategory>(categories);
    }

    private static SettingCategory getCategory(List<SettingCategory> categories, string categoryName) {
      foreach (SettingCategory category in categories) {
        if (category.Name == categoryName) {
          return category;
        }
      }
      categories.Add(new SettingCategory(categoryName));
      return CategoryFactory.getCategory(categories, categoryName);
    }
    private static SettingGroup getGroup(SettingCategory category, string groupName) {
      foreach (SettingGroup group in category.Groups) {
        if (group.Name == groupName) {
          return group;
        }
      }
      category.Groups.Add(new SettingGroup(groupName));
      return CategoryFactory.getGroup(category, groupName);
    }
  }
}