﻿using System.Drawing;
using System.Windows.Forms;

namespace SettingsManager {
  public class GroupTitle : Label {
    public GroupTitle(string text) {
      this.Text = text;
      this.Font = new Font(SystemFonts.CaptionFont.FontFamily, 12); ;
      this.ForeColor = SystemColors.HotTrack;
      this.TextAlign = ContentAlignment.MiddleLeft;
      this.AutoSize = true;
      this.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;
    }
    protected override void OnPaint(PaintEventArgs e) {
      e.Graphics.DrawLine(Pens.Gray, 0, this.Height - 1, this.Width - 1, this.Height - 1);
      base.OnPaint(e);
    }
  }
}
