﻿using System;
using System.Reflection;

namespace SettingsManager {
  /// <summary>
  /// Apply this class to any settings in your custom SettingsBase object.
  /// </summary>
  [AttributeUsage(AttributeTargets.Property)]
  public sealed class SettingAttribute : Attribute {
    private string category;
    public string Category { get { return this.category; } }

    private string group;
    public string Group { get { return this.group; } }

    private string description;
    public string Description { get { return this.description; } }

    private Type editorType;
    public Type EditorType { get { return this.editorType; } }

    public SettingAttribute(string category, string group, string description, Type editorType) {
      this.category = category;
      this.group = group;
      this.description = description;
      this.editorType = editorType;
    }
  }
}