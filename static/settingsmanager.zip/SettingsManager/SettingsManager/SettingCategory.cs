﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace SettingsManager {
  public class SettingCategory {
    private string name;
    public string Name { get { return this.name; } }

    private Collection<SettingGroup> groups = new Collection<SettingGroup>();
    public Collection<SettingGroup> Groups { get { return this.groups; } }
    
    internal SettingCategory(string name) {
      this.name = name;
    }
  }
}
