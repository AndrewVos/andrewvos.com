﻿using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace SettingsManager {
  public abstract class SettingEditorBase : TableLayoutPanel {
    internal SettingsBase settings;
    internal PropertyInfo propertyInfo;

    private string text;
    public override string Text { get { return this.text; } set { this.text = value; } }

    private object settingValue;
    public object SettingValue { get { return this.settingValue; } }

    private bool isDirty;
    public bool IsDirty { get { return this.isDirty; } }

    public event EventHandler SettingChanged;

    protected SettingEditorBase(string text, object settingValue) {
      this.text = text;
      this.settingValue = settingValue;
      this.AutoSize = true;
      this.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
    }

    public void OnSettingChanged(object newValue) {
      this.isDirty = true;
      this.settingValue = newValue;
      if (this.SettingChanged != null) {
        this.SettingChanged(this, EventArgs.Empty);
      }
    }
    public void AddLabel(string text) {
      Label label = new Label();
      label.Text = text;
      label.AutoSize = true;
      label.TextAlign = ContentAlignment.MiddleLeft;
      this.Controls.Add(label);
    }

    internal void applySetting() {
      if (this.IsDirty) {
        this.propertyInfo.SetValue(this.settings, this.SettingValue, null);
        this.isDirty = false;
      }
    }
  }
}