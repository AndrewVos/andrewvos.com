﻿using System;
using System.Windows.Forms;

namespace SettingsManager.SettingEditors {
  public class BooleanEditor : SettingEditorBase {
    private CheckBox checkBox;

    public BooleanEditor(string text, object settingValue)
      : base(text, settingValue) {
      this.checkBox = new CheckBox();
      this.checkBox.Checked = (bool)settingValue;
      this.checkBox.Text = this.Text;
      this.checkBox.AutoSize = true;
      this.Controls.Add(this.checkBox);
      this.checkBox.CheckedChanged += new EventHandler(checkBox_CheckedChanged);
    }

    private void checkBox_CheckedChanged(object sender, EventArgs e) {
      this.OnSettingChanged(this.checkBox.Checked);
    }
  }
}
