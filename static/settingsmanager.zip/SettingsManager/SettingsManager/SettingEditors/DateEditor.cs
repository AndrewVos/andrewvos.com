﻿using System;
using System.Windows.Forms;

namespace SettingsManager.SettingEditors {
  public class DateEditor : SettingEditorBase {
    DateTimePicker datePicker;
    public DateEditor(string text, object settingValue)
      : base(text, settingValue) {

      this.AddLabel(text);

      this.datePicker = new DateTimePicker();
      this.datePicker.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

      this.datePicker.Value = (DateTime)settingValue;
      this.datePicker.ValueChanged += new EventHandler(datePicker_ValueChanged);
      this.Controls.Add(datePicker);
    }

    private void datePicker_ValueChanged(object sender, EventArgs e) {
      this.OnSettingChanged(this.datePicker.Value);
    }
  }
}
