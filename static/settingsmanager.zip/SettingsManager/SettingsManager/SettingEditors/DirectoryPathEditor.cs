﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SettingsManager.SettingEditors {
  public class DirectoryPathEditor : SettingEditorBase {

    private FolderBrowserDialog fbd;
    private Button chooseFolder;
    private TextBox directoryPath;

    public DirectoryPathEditor(string text, object settingValue)
      : base(text, settingValue) {

      this.fbd = new FolderBrowserDialog();
      this.fbd.Description = text;

      this.AddLabel(this.Text);

      this.directoryPath = new TextBox();
      this.directoryPath.Text = settingValue.ToString();
      this.directoryPath.Dock = DockStyle.Fill;
      this.directoryPath.TextChanged += new EventHandler(directoryPath_TextChanged);

      this.chooseFolder = new Button();
      this.chooseFolder.AutoSize = true;
      this.chooseFolder.Dock = DockStyle.Right;
      this.chooseFolder.Text = "...";
      this.chooseFolder.Size = new Size(this.directoryPath.Height, this.directoryPath.Height);
      this.chooseFolder.Click += new EventHandler(chooseFolder_Click);

      Panel contentPanel = new Panel();
      contentPanel.Height = this.directoryPath.Height;
      contentPanel.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top;

      contentPanel.Controls.Add(this.directoryPath);
      contentPanel.Controls.Add(this.chooseFolder);

      this.Controls.Add(contentPanel);
    }

    private void directoryPath_TextChanged(object sender, EventArgs e) {
      this.OnSettingChanged(this.directoryPath.Text);
    }
    private void chooseFolder_Click(object sender, EventArgs e) {
      if (fbd.ShowDialog() == DialogResult.OK) {
        this.directoryPath.Text = fbd.SelectedPath;
      }
    }
  }
}