﻿using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Forms;

namespace SettingsManager.SettingEditors {
  public class EnumEditor : SettingEditorBase {
    public EnumEditor(string text, object settingValue)
      : base(text, settingValue) {

      this.AddLabel(this.Text);

      foreach (object value in Enum.GetValues(settingValue.GetType())) {
        FieldInfo fieldInfo = settingValue.GetType().GetField(Enum.GetName(settingValue.GetType(), value));
        object[] customAttributes = fieldInfo.GetCustomAttributes(false);

        foreach (DescriptionAttribute description in customAttributes) {
          RadioButton radioButton = new RadioButton();
          radioButton.Tag = value;
          radioButton.Checked = (value.Equals(settingValue));
          radioButton.Text = description.Description;
          radioButton.AutoSize = true;
          this.Controls.Add(radioButton);
          radioButton.CheckedChanged += new EventHandler(radioButton_CheckedChanged);
        }
      }
    }

    private void radioButton_CheckedChanged(object sender, EventArgs e) {
      RadioButton radioButton = (RadioButton)sender;
      if (radioButton.Checked) {
        this.OnSettingChanged(radioButton.Tag);
      }
    }
  }
}
