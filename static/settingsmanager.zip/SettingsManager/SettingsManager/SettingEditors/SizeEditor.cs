﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SettingsManager.SettingEditors {
  public class SizeEditor : SettingEditorBase {

    private NumericUpDown nudWidth;
    private NumericUpDown nudHeight;

    public SizeEditor(string text, object settingValue)
      : base(text, settingValue) {

      Size size = (Size)settingValue;

      this.AddLabel(this.Text);

      SplitContainer splitContainer = new SplitContainer();
      splitContainer.Dock = DockStyle.Fill;

      this.nudWidth = new NumericUpDown();
      this.nudWidth.Dock = DockStyle.Fill;
      this.nudWidth.Maximum = int.MaxValue;
      this.nudWidth.Value = size.Width;
      this.nudWidth.ValueChanged += new EventHandler(nud_ValueChanged);

      this.nudHeight = new NumericUpDown();
      this.nudHeight.Dock = DockStyle.Fill;
      this.nudHeight.Maximum = int.MaxValue;
      this.nudHeight.Value = size.Height;
      this.nudHeight.ValueChanged += new EventHandler(nud_ValueChanged);

      splitContainer.Panel1.Controls.Add(this.nudWidth);
      splitContainer.Panel2.Controls.Add(this.nudHeight);

      splitContainer.SplitterDistance = (splitContainer.Width / 2);
      splitContainer.IsSplitterFixed = true;

      splitContainer.Height = this.nudWidth.Height;

      this.Controls.Add(splitContainer);

    }

    private void nud_ValueChanged(object sender, System.EventArgs e) {
      this.OnSettingChanged(new Size((int)this.nudWidth.Value, (int)this.nudHeight.Value));
    }

  }
}
