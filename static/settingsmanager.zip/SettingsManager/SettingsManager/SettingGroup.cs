﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System;

namespace SettingsManager {
  public class SettingGroup {
    private string name;
    public string Name { get { return this.name; } }

    private Collection<SettingEditorBase> editors = new Collection<SettingEditorBase>();
    public Collection<SettingEditorBase> Editors { get { return this.editors; } }

    internal SettingGroup(string name) {
      this.name = name;
    }
  }
}
