﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Xml.Serialization;

namespace SettingsManager {
  /// <summary>
  /// Create your own custom settings class and inherit from SettingsBase to use with a settings form.
  /// </summary>
  public abstract class SettingsBase {
    [SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
    public static T Load<T>(string filePath) {
      //If the settings file is corrupt or not there try load from
      //the backup file, otherwise return null.
      object settings = SettingsBase.tryLoad(filePath, typeof(T));
      if (settings == null) {
        settings = SettingsBase.tryLoad(filePath + ".bak", typeof(T));
      }
      return (T)settings;
    }
    private static object tryLoad(string path, Type type) {
      if (File.Exists(path)) {
        try {
          XmlSerializer serializer = new XmlSerializer(type);
          TextReader reader = new StreamReader(path);
          SettingsBase settings = (SettingsBase)serializer.Deserialize(reader);
          reader.Close();
          return settings;
        } catch (InvalidOperationException) { }
      }

      return null;
    }

    public void Save(string filePath) {
      if (File.Exists(filePath)) {
        //Make a backup.
        File.Copy(filePath, filePath + ".bak", true);
      }

      XmlSerializer serializer = new XmlSerializer(this.GetType());
      TextWriter writer = new StreamWriter(filePath, false);
      serializer.Serialize(writer, this);
      writer.Close();
    }

  }
}