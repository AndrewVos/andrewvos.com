﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace SettingsManager {
  public abstract partial class SettingsFormBase : Form {
    private SettingsBase settings;
    public SettingsBase Settings { get { return this.settings; } }

    private ReadOnlyCollection<SettingCategory> categories;
    public ReadOnlyCollection<SettingCategory> Categories { get { return this.categories; } }

    public event EventHandler AppliedSettings;

    protected SettingsFormBase(SettingsBase settings) {
      InitializeComponent();

      this.settings = settings;

      Stream iconStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("SettingsManager.Resources.settings.ico");
      this.Icon = new Icon(iconStream);
      iconStream.Close();
    }

    public abstract void InitializeEditors(Panel contentPanel);

    public virtual new DialogResult ShowDialog() {
      this.initializeEditors();
      return base.ShowDialog();
    }
    public virtual new DialogResult ShowDialog(IWin32Window owner) {
      this.initializeEditors();
      return base.ShowDialog(owner);
    }
    public virtual new void Show() {
      this.initializeEditors();
      base.Show();
    }
    public virtual new void Show(IWin32Window owner) {
      this.initializeEditors();
      base.Show(owner);
    }

    

    private void initializeEditors() {
      this.content.Controls.Clear();

      this.categories = CategoryFactory.GetCategories(this.Settings);

      foreach (SettingCategory category in this.Categories) {
        foreach (SettingGroup group in category.Groups) {
          foreach (SettingEditorBase editor in group.Editors) {
            editor.SettingChanged +=new EventHandler(editor_SettingChanged);
          }
        }
      }
      this.InitializeEditors(this.content);
    }
    private void applySettings() {
      foreach (SettingCategory category in this.Categories) {
        foreach (SettingGroup group in category.Groups) {
          foreach (SettingEditorBase editor in group.Editors) {
            editor.applySetting();
          }
        }
      }

      this.apply.Enabled = false;

      if (this.AppliedSettings != null) {
        this.AppliedSettings(this, EventArgs.Empty);
      }
    }

    private void editor_SettingChanged(object sender, EventArgs e) {
      this.apply.Enabled = true;
    }
    private void ok_Click(object sender, EventArgs e) {
      this.applySettings();
      this.Visible = false;
    }
    private void cancel_Click(object sender, EventArgs e) {
      this.Visible = false;
    }
    private void apply_Click(object sender, EventArgs e) {
      this.applySettings();
    }
    private void SettingsFormBase_FormClosing(object sender, FormClosingEventArgs e) {
      e.Cancel = true;
      this.Visible = false;
    }
  }
}
