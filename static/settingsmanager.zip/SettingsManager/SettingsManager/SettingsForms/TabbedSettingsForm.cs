﻿using System.Windows.Forms;

namespace SettingsManager {
  public class TabbedSettingsForm : SettingsFormBase {
    TabControl tabControl;
    public TabbedSettingsForm(SettingsBase settings)
      : base(settings) {
      this.Padding = new Padding(10);


    }

    public override void InitializeEditors(Panel contentPanel) {
      this.tabControl = new TabControl();
      this.tabControl.Dock = DockStyle.Fill;
      contentPanel.Controls.Add(this.tabControl);

      foreach (SettingCategory category in this.Categories) {
        TabPage tabPage = new TabPage(category.Name);
        tabPage.AutoSize = true;
        this.tabControl.TabPages.Add(tabPage);

        TableLayoutPanel content = new TableLayoutPanel();
        content.Dock = DockStyle.Fill;
        content.AutoScroll = true;
        tabPage.Controls.Add(content);

        foreach (SettingGroup group in category.Groups) {
          content.Controls.Add(new GroupTitle(group.Name));
          foreach (SettingEditorBase editor in group.Editors) {
            content.Controls.Add(editor);
          }
        }
      }
    }
  }
}
