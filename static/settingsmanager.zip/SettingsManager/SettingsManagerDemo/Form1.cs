﻿using System;
using System.Windows.Forms;
using SettingsManager;

namespace SettingsManagerDemo {
  public partial class Form1 : Form {
    MySettings settings;
    TabbedSettingsForm sf;

    public Form1() {
      InitializeComponent();
    }
    private string settingsFilePath = Application.UserAppDataPath + "\\settings.xml";
    private void Form1_Load(object sender, EventArgs e) {
      this.settings = SettingsBase.Load<MySettings>(this.settingsFilePath);

      if (this.settings == null) {
        this.settings = new MySettings();
      }
      this.propertyGrid1.SelectedObject = this.settings;

      this.sf = new TabbedSettingsForm(this.settings);
      this.sf.Text = "Settings";

      this.sf.AppliedSettings += new EventHandler(sf_AppliedSettings);
    }

    private void settingsToolStripMenuItem_Click(object sender, EventArgs e) {
      this.sf.ShowDialog();
    }

    private void sf_AppliedSettings(object sender, EventArgs e) {
      this.settings.Save(this.settingsFilePath);
      this.propertyGrid1.SelectedObject = this.settings;
    }
  }
}
