﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using SettingsManager;
using SettingsManager.SettingEditors;
using System.Drawing;

namespace SettingsManagerDemo {
  public class MySettings : SettingsBase {
    //Demo Category // Booleans
    private bool someBoolean1 = true;
    [Setting("Demo Category", "Booleans", "Please check this box.", typeof(BooleanEditor))]
    public bool SomeBoolean1 { get { return this.someBoolean1; } set { this.someBoolean1 = value; } }

    //Demo Category // Enums
    private SomeEnum someEnum;
    [Setting("Demo Category", "Enums", "Please choose a value from the list below.", typeof(EnumEditor))]
    public SomeEnum SomeEnum { get { return this.someEnum; } set { this.someEnum = value; } }

    //Demo Category // Dates
    private DateTime someDate = DateTime.Today;
    [Setting("Demo Category", "Dates", "Please choose a date.", typeof(DateEditor))]
    public DateTime SomeDate { get { return this.someDate; } set { this.someDate = value; } }

    //Demo Category // Sizes
    private Size size = new Size(128, 128);
    [Setting("Demo Category", "Sizes", "Please choose a size.", typeof(SizeEditor))]
    public Size Size { get { return this.size; } set { this.size = value; } }

    //Demo Category // Directory Paths
    private string somePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
    [Setting("Demo Category", "Directory Paths", "Please choose a directory.", typeof(DirectoryPathEditor))]
    public string SomePath { get { return this.somePath; } set { this.somePath = value; } }

  

  }
  public enum SomeEnum {
    [Description("Some Enum Value 1")]
    SomeEnumValue1,
    [Description("Some Enum Value 2")]
    SomeEnumValue2,
    [Description("Some Enum Value 3")]
    SomeEnumValue3,
    [Description("Some Enum Value 4")]
    SomeEnumValue4,
    [Description("Some Enum Value 5")]
    SomeEnumValue5
  }
}
