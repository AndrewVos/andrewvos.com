﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace SettingsManagerDemo {
  public enum PlacesToGo {
    [Description("Go to Australia")]
    Australia,
    [Description("Go to the mall")]
    Mall,
    [Description("Go to space")]
    Space
  }
}
