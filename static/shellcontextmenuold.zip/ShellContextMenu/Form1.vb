Imports System.Runtime.InteropServices

Public Class Form1

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim names() As String = [Enum].GetNames(GetType(Environment.SpecialFolder))
    Dim values() As Integer = CType([Enum].GetValues(GetType(Environment.SpecialFolder)), Integer())
    For index As Integer = 0 To names.Length - 1
      Me.ListView1.Items.Add(names(index)).Tag = values(index)
    Next index
    Me.ListView1.Sorting = SortOrder.Ascending

    Me.loadFiles(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments))
  End Sub
  'Private iContextMenu2 As IContextMenu2
  'Public Sub PopupMenu(ByVal path As String, ByVal parent As IntPtr)
  '  Me.PopUpContextMenu(PInvoke.ILCreateFromPath(path), parent)
  'End Sub


  'Private Sub PopUpContextMenu(ByVal pIDL As IntPtr, ByVal hwndParent As IntPtr)
  '  Dim ppv As IShellFolder = Nothing
  '  Dim menu As New ContextMenu
  '  Try
  '    Dim ptr As IntPtr
  '    If (((pIDL <> IntPtr.Zero) AndAlso (PInvoke.SHBindToParent(pIDL, PInvoke.IID_IShellFolder, ppv, ptr) = 0)) AndAlso (Not ppv Is Nothing)) Then
  '      Dim apidl As IntPtr() = New IntPtr() {ptr}
  '      Dim rgfReserved As UInt32 = 0
  '      Dim riid As Guid = PInvoke.IID_IContextMenu
  '      Dim obj2 As Object = Nothing
  '      ppv.GetUIObjectOf(IntPtr.Zero, System.Convert.ToUInt32(apidl.Length), apidl, (riid), (rgfReserved), obj2)
  '      If (Not Me.iContextMenu2 Is Nothing) Then
  '        Marshal.ReleaseComObject(Me.iContextMenu2)
  '        Me.iContextMenu2 = Nothing
  '      End If
  '      Me.iContextMenu2 = TryCast(obj2, IContextMenu2)
  '      If (Not Me.iContextMenu2 Is Nothing) Then
  '        Dim mousePosition As Point = Control.MousePosition

  '        Dim uFlags As UInt32
  '        If (Control.ModifierKeys And Keys.Shift) = Keys.Shift Then
  '          uFlags = 256
  '        Else
  '          uFlags = 0
  '        End If

  '        Me.iContextMenu2.QueryContextMenu(menu.Handle, 0, 1, 65535, uFlags)
  '        Dim num3 As UInt32 = PInvoke.TrackPopupMenu(menu.Handle, 256, mousePosition.X, mousePosition.Y, 0, hwndParent, IntPtr.Zero)
  '        If (num3 <> 0) Then
  '          Dim cmici As New CMINVOKECOMMANDINFO
  '          cmici.cbSize = Marshal.SizeOf(cmici)
  '          cmici.fMask = 0
  '          cmici.hwnd = Me.Handle
  '          cmici.lpVerb = CType(((num3 - 1) And 65535), IntPtr)
  '          cmici.lpParameters = IntPtr.Zero
  '          cmici.lpDirectory = IntPtr.Zero
  '          cmici.nShow = 1
  '          cmici.dwHotKey = 0
  '          cmici.hIcon = IntPtr.Zero
  '          Me.iContextMenu2.InvokeCommand((cmici))
  '        End If
  '      End If
  '    End If
  '  Catch exception As Exception

  '  Finally
  '    If (Not ppv Is Nothing) Then
  '      Marshal.ReleaseComObject(ppv)
  '      ppv = Nothing
  '    End If
  '    If (Not menu Is Nothing) Then
  '      menu.Dispose()
  '    End If
  '  End Try
  'End Sub
  'Friend Const WM_CONTEXTMENU As Integer = 123
  'Friend Const WM_INITMENUPOPUP As Integer = 279
  'Friend Const WM_DRAWITEM As Integer = 43
  'Friend Const WM_MEASUREITEM As Integer = 44

  'Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
  '  If (((m.Msg = 279) OrElse (m.Msg = 43)) OrElse (m.Msg = 44)) Then
  '    If (Not Me.iContextMenu2 Is Nothing) Then
  '      Try
  '        Me.iContextMenu2.HandleMenuMsg(m.Msg, m.WParam, m.LParam)
  '        Return
  '      Catch
  '      End Try
  '    End If
  '  ElseIf (m.Msg = Me.WM_CONTEXTMENU) Then
  '    Return
  '  End If
  '  MyBase.WndProc(m)
  'End Sub

  Private Sub ListView1_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView1.MouseUp
    If e.Button = Windows.Forms.MouseButtons.Right Then
      If Not Me.ListView1.SelectedItems.Count = 0 Then
        Dim sf As Environment.SpecialFolder = CType(Me.ListView1.SelectedItems(0).Tag, Environment.SpecialFolder)
        Dim f As New ShellContextMenu
        MessageBox.Show(f.PopupMenu(sf, Me.Handle).ToString)
        f = Nothing
      End If
    End If
  End Sub

  Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
    Dim fbd As New FolderBrowserDialog
    If fbd.ShowDialog = Windows.Forms.DialogResult.OK Then
      Me.loadFiles(fbd.SelectedPath)
    End If
  End Sub
  Private Sub loadFiles(ByVal path As String)
    Me.Text = path

    Me.ListView2.Items.Clear()

    Dim files() As String
    Dim directories() As String
    Try
      files = IO.Directory.GetFiles(path)
    Catch ex As Exception
      files = Nothing
    End Try
    Try
      directories = IO.Directory.GetDirectories(path)
    Catch ex As Exception
      directories = Nothing
    End Try

    If Not files Is Nothing Then
      For Each file As String In files
        Dim fi As New IO.FileInfo(file)
        Me.ListView2.Items.Add(fi.Name).Tag = fi.FullName
      Next file
    End If

    If Not directories Is Nothing Then
      For Each directory As String In directories
        Dim di As New IO.DirectoryInfo(directory)
        Me.ListView2.Items.Add(di.Name).Tag = di.FullName
      Next directory
    End If
  End Sub

  Private Sub ListView2_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView2.MouseUp
    If e.Button = Windows.Forms.MouseButtons.Right Then
      If Not Me.ListView2.SelectedItems.Count = 0 Then
        Dim paths As New Generic.List(Of String)
        If Not Me.ListView2.SelectedItems.Count = 0 Then
          For Each item As ListViewItem In Me.ListView2.SelectedItems
            paths.Add(item.Tag.ToString)
          Next item
        End If
        Dim f As New ShellContextMenu
        MessageBox.Show(f.PopupMenu(paths, Me.Handle).ToString)
        f = Nothing
      End If
    End If
  End Sub
End Class
