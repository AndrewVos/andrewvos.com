Imports System.Runtime.InteropServices

Public Class ShellContextMenu
  Private iscm As internalShellContextMenu
  Public Sub New()
    Me.iscm = New internalShellContextMenu
  End Sub

  Public Function PopupMenu(ByVal specialFolder As Environment.SpecialFolder, ByVal parent As IntPtr) As ContextMenuResult
    Return Me.iscm.PopupMenu(specialFolder, parent)
  End Function
  Public Function PopupMenu(ByVal path As String, ByVal parent As IntPtr) As ContextMenuResult
    Return Me.iscm.PopupMenu(path, parent)
  End Function
  Public Function PopupMenu(ByVal paths As Generic.List(Of String), ByVal parent As IntPtr) As ContextMenuResult
    Return Me.iscm.PopupMenu(paths, parent)
  End Function

  Public Enum ContextMenuResult
    NoUserFeedback
    Cut
    Copy
    Paste
    CreateShortcut
    Delete
    Rename
    Properties
    ContextMenuError
    SharingAndSecurity
  End Enum
  Private Class internalShellContextMenu
    Inherits NativeWindow
    Public Sub New()
      MyBase.New()
    End Sub

    Private contextMenu2 As Win32.IContextMenu2
    Public Function PopupMenu(ByVal specialFolder As Environment.SpecialFolder, ByVal parent As IntPtr) As ContextMenuResult
      Me.AssignHandle(parent)
      Dim result As ContextMenuResult = Me.PopUpContextMenu(Me.GetPIDLFromFolderID(parent, specialFolder), parent)
      Me.ReleaseHandle()
      Return result
    End Function
    Public Function PopupMenu(ByVal path As String, ByVal parent As IntPtr) As ContextMenuResult
      Me.AssignHandle(parent)
      Dim result As ContextMenuResult = Me.PopUpContextMenu(Win32.ILCreateFromPath(path), parent)
      Me.ReleaseHandle()
      Return result
    End Function
    Public Function PopupMenu(ByVal paths As Generic.List(Of String), ByVal parent As IntPtr) As ContextMenuResult
      Me.AssignHandle(parent)
      Dim p As New Generic.List(Of IntPtr)
      For Each path As String In paths
        p.Add(Win32.ILCreateFromPath(path))
      Next path
      Dim result As ContextMenuResult = Me.PopupContextMenu(p.ToArray, parent)
      Me.ReleaseHandle()
      Return result
    End Function

    Private Function PopupContextMenu(ByVal pidl As IntPtr, ByVal parent As IntPtr) As ContextMenuResult
      Return Me.PopupContextMenu(New IntPtr() {pidl}, parent)
    End Function
    Private Function PopUpContextMenu(ByVal pidls() As IntPtr, ByVal parent As IntPtr) As ContextMenuResult
      Dim result As ContextMenuResult = ContextMenuResult.NoUserFeedback

      Dim menu As New ContextMenu
      Dim pidlList As New Generic.List(Of IntPtr)
      Dim iShellFolder As Win32.IShellFolder = Nothing
      Try
        For Each pidl As IntPtr In pidls
          Dim ptr As IntPtr = Nothing
          If (((pidl <> IntPtr.Zero) AndAlso (Win32.SHBindToParent(pidl, Win32.IID_IShellFolder, iShellFolder, ptr) = 0)) AndAlso (Not iShellFolder Is Nothing)) Then
            pidlList.Add(ptr)
          End If
        Next pidl

        Dim apidl As IntPtr() = pidlList.ToArray
        Dim rgfReserved As UInt32 = 0
        Dim riid As Guid = Win32.IID_IContextMenu
        Dim obj2 As Object = Nothing
        iShellFolder.GetUIObjectOf(IntPtr.Zero, System.Convert.ToUInt32(apidl.Length), apidl, (riid), (rgfReserved), obj2)

        If (Not Me.contextMenu2 Is Nothing) Then
          Marshal.ReleaseComObject(Me.contextMenu2)
          Me.contextMenu2 = Nothing
        End If

        Me.contextMenu2 = TryCast(obj2, Win32.IContextMenu2)
        If (Not Me.contextMenu2 Is Nothing) Then
          Dim mousePosition As Point = Control.MousePosition

          Dim uFlags As UInt32
          If (Control.ModifierKeys And Keys.Shift) = Keys.Shift Then
            uFlags = 256
          Else
            uFlags = 0
          End If

          Me.contextMenu2.QueryContextMenu(menu.Handle, 0, 1, 65535, uFlags)
          Dim menuResult As UInt32 = Win32.TrackPopupMenu(menu.Handle, 256, mousePosition.X, mousePosition.Y, 0, parent, IntPtr.Zero)
          If (menuResult <> 0) Then
            Dim cmici As New Win32.CMINVOKECOMMANDINFO
            cmici.cbSize = Marshal.SizeOf(cmici)
            cmici.fMask = 0
            cmici.hwnd = Me.Handle
            cmici.lpVerb = CType(((menuResult - 1) And 65535), IntPtr)
            cmici.lpParameters = IntPtr.Zero
            cmici.lpDirectory = IntPtr.Zero
            cmici.nShow = 1
            cmici.dwHotKey = 0
            cmici.hIcon = IntPtr.Zero
            Me.contextMenu2.InvokeCommand((cmici))
          End If

          Select Case menuResult
            Case 0
              result = ContextMenuResult.NoUserFeedback
            Case 25
              result = ContextMenuResult.Cut
            Case 26
              result = ContextMenuResult.Copy
            Case 27
              result = ContextMenuResult.Paste
            Case 17
              result = ContextMenuResult.CreateShortcut
            Case 18
              result = ContextMenuResult.Delete
            Case 19
              result = ContextMenuResult.Rename
            Case 20
              result = ContextMenuResult.Properties
            Case 94
              result = ContextMenuResult.SharingAndSecurity
            Case Else
          End Select
        End If
      Catch exception As Exception
        result = ContextMenuResult.ContextMenuError
      Finally
        If (Not iShellFolder Is Nothing) Then
          Marshal.ReleaseComObject(iShellFolder)
          iShellFolder = Nothing
        End If
        If (Not menu Is Nothing) Then
          menu.Dispose()
        End If
      End Try

      Return result
    End Function

    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
      Select Case m.Msg
        Case Win32.WM.INITMENUPOPUP, Win32.WM.DRAWITEM, Win32.WM.MEASUREITEM
          If (Not Me.contextMenu2 Is Nothing) Then
            Try
              Me.contextMenu2.HandleMenuMsg(m.Msg, m.WParam, m.LParam)
              Return
            Catch
            End Try
          End If
        Case Win32.WM.CONTEXTMENU
          Return
        Case Else
          MyBase.WndProc(m)
      End Select
    End Sub

    Public Function GetPIDLFromFolderID(ByVal owner As IntPtr, ByVal specialFolder As Environment.SpecialFolder) As IntPtr
      Dim pidl As IntPtr
      If Win32.SHGetSpecialFolderLocation(owner, specialFolder, pidl) = Win32.ERROR_SUCCESS Then
        Return pidl
      End If
    End Function

    Private Class Win32
      <DllImport("shell32.dll")> Public Shared Function SHBindToParent(ByVal pidl As IntPtr, <MarshalAs(UnmanagedType.LPStruct)> ByVal riid As Guid, <Out()> ByRef ppv As IShellFolder, <Out()> ByRef ppidlLast As IntPtr) As Integer
      End Function
      <DllImport("shell32.dll", CharSet:=CharSet.Auto)> Public Shared Function ILCreateFromPath(<MarshalAs(UnmanagedType.LPTStr)> ByVal pszPath As String) As IntPtr
      End Function
      <DllImport("user32.dll")> Public Shared Function TrackPopupMenu(ByVal hMenu As IntPtr, ByVal uFlags As UInt32, ByVal x As Integer, ByVal y As Integer, ByVal nReserved As Integer, ByVal hWnd As IntPtr, ByVal prcRect As IntPtr) As UInt32
      End Function
      <DllImport("shell32.dll")> Public Shared Function SHGetSpecialFolderLocation(ByVal hwnd As IntPtr, ByVal csidl As Integer, ByRef ppidl As IntPtr) As Integer
      End Function

      Public Const ERROR_SUCCESS As Integer = 0

      Public Shared IID_IShellFolder As New Guid("{000214E6-0000-0000-C000-000000000046}")
      Public Shared IID_IContextMenu As New Guid("{000214e4-0000-0000-c000-000000000046}")

      Public Class WM
        Public Const CONTEXTMENU As Integer = 123
        Public Const INITMENUPOPUP As Integer = 279
        Public Const DRAWITEM As Integer = 43
        Public Const MEASUREITEM As Integer = 44
      End Class
      <StructLayout(LayoutKind.Sequential)> Public Structure CMINVOKECOMMANDINFO
        Public cbSize As Integer
        Public fMask As Integer
        Public hwnd As IntPtr
        Public lpVerb As IntPtr
        Public lpParameters As IntPtr
        Public lpDirectory As IntPtr
        Public nShow As Integer
        Public dwHotKey As Integer
        Public hIcon As IntPtr
      End Structure
      <ComImport(), InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("000214F4-0000-0000-c000-000000000046")> Public Interface IContextMenu2
        <PreserveSig()> _
        Function QueryContextMenu(ByVal hMenu As IntPtr, ByVal indexMenu As UInt32, ByVal idCmdFirst As UInt32, ByVal idCmdLast As UInt32, ByVal uFlags As UInt32) As Integer
        <PreserveSig()> _
        Function InvokeCommand(ByRef pici As CMINVOKECOMMANDINFO) As Integer
        Sub GetCommandString(ByVal idCmd As UInt32, ByVal uFlags As UInt32, ByRef pwReserved As Integer, ByVal commandstring As IntPtr, ByVal cch As UInt32)
        <PreserveSig()> _
        Function HandleMenuMsg(ByVal uMsg As Integer, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As Integer
      End Interface
      <ComImport(), Guid("000214F2-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> Public Interface IEnumIDList
        <PreserveSig()> _
        Function [Next](ByVal celt As UInt32, <Out()> ByRef rgelt As IntPtr, ByVal pceltFetched As Object) As Integer
        Sub Skip(ByVal celt As UInt32)
        Sub Reset()
        Sub Clone(<Out()> ByRef ppenum As IEnumIDList)
      End Interface
      <ComImport(), Guid("000214E6-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)> Public Interface IShellFolder
        <PreserveSig()> _
        Function ParseDisplayName(ByVal hwnd As IntPtr, ByVal pbc As IntPtr, <MarshalAs(UnmanagedType.LPWStr)> ByVal pszDisplayName As String, ByRef pchEaten As UInt32, <Out()> ByRef ppidl As IntPtr, ByRef pdwAttributes As UInt32) As Integer
        <PreserveSig()> _
        Function EnumObjects(ByVal hwnd As IntPtr, ByVal grfFlags As Integer, <Out()> ByRef ppenumIDList As IEnumIDList) As Integer
        <PreserveSig()> _
        Function BindToObject(ByVal pidl As IntPtr, ByVal pbc As IntPtr, <[In]()> ByRef riid As Guid, <Out()> ByRef ppv As IShellFolder) As Integer
        Sub BindToStorage(ByVal pidl As IntPtr, ByVal pbc As IntPtr, ByVal riid As Guid, <Out()> ByRef ppv As IntPtr)
        <PreserveSig()> _
        Function CompareIDs(ByVal lParam As IntPtr, ByVal pidl1 As IntPtr, ByVal pidl2 As IntPtr) As Integer
        Sub CreateViewObject(ByVal hwndOwner As IntPtr, ByVal riid As Guid, <Out()> ByRef ppv As IntPtr)
        <PreserveSig()> _
        Function GetAttributesOf(ByVal cidl As UInt32, <MarshalAs(UnmanagedType.LPArray, SizeParamIndex:=0)> ByVal apidl As IntPtr(), ByRef rgfInOut As UInt32) As Integer
        Sub GetUIObjectOf(ByVal hwndOwner As IntPtr, ByVal cidl As UInt32, <MarshalAs(UnmanagedType.LPArray)> ByVal apidl As IntPtr(), ByRef riid As Guid, ByRef rgfReserved As UInt32, <Out(), MarshalAs(UnmanagedType.Interface)> ByRef ppv As Object)
        Sub GetDisplayNameOf(ByVal pidl As IntPtr, ByVal uFlags As UInt32, <Out()> ByRef pName As IntPtr)
        Sub SetNameOf(ByVal hwnd As IntPtr, ByVal pidl As IntPtr, <MarshalAs(UnmanagedType.LPWStr)> ByVal pszName As String, ByVal uFlags As UInt32, <Out()> ByRef ppidlOut As IntPtr)
      End Interface
    End Class
   
  End Class
End Class